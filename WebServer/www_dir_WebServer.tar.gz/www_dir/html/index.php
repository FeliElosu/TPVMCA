<?php

$servername = "192.168.0.147";
$port = "3306";
$username = "lcars";
$password = "NCC1701D";
$dbname = "ingenieria";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$sql = "SELECT alumnos.legajo 'legajo', 
               alumnos.apellido 'apellido', 
               alumnos.nombres 'nombre',
               modulos.nom_modulo 'materia', 
               notas.nota 'nota'
        FROM alumnos, 
             modulos, 
             notas 
        WHERE alumnos.legajo = notas.legajo 
          AND modulos.cod_modulo = notas.cod_modulo";

if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        echo "legajo: " . $row["legajo"] . " - Nombre: " . $row["nombre"] . " " . $row["apellido"] . " | Materia: " . $row["materia"] . " ---> Nota: " . $row["nota"] . "<br>";
    }
}

$conn->close();
?>
