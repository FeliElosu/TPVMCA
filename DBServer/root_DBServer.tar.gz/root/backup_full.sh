  #!/bin/bash
 
  # Función de ayuda
  print_help() {
      echo "Uso: $0 [-h] <origen> <destino>"
      echo "   -h: Muestra esta ayuda"
      echo "   origen: Directorio de origen del respaldo"
      echo "   destino: Directorio de destino del respaldo"
  }
 
  # Verificación de argumentos
  if [[ $# -eq 0 || "$1" == "-h" ]]; then
      print_help
      exit 0
  elif [[ $# -ne 2 ]]; then
      echo "Error: Debes especificar el directorio de origen y destino."
      print_help
      exit 1
  fi
 
  # Variables de origen y destino
  origen="$1"
  destino="$2"
 
  # Verificar si los directorios origen y destino existen
  if [[ ! -d "$origen" ]]; then
      echo "Error: El directorio de origen '$origen' no existe."
      exit 1
  fi
 
  if [[ ! -d "$destino" ]]; then
      echo "Error: El directorio de destino '$destino' no existe."
      exit 1
 fi

  # Función para realizar el respaldo
  backup() {
      local source_dir="$1"
      local dest_dir="$2"
      local backup_name="$3"
 
      tar -czf "$dest_dir/$backup_name.tar.gz" -C "$source_dir" .
      echo "Backup completado: $backup_name.tar.gz"
  }
 
  # Obtener la fecha en formato ANSI (YYYYMMDD)
  current_date=$(date +"%Y%m%d")
 
  # Realizar el respaldo del directorio de origen al directorio de destino
  backup "$origen" "$destino" "$(basename "$origen")_bkp_$current_date"
